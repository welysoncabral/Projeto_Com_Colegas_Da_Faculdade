package br.com.barbearia.braddock.repository;

import br.com.barbearia.braddock.domain.Servico;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ServicoRepository extends JpaRepository<Servico, Long> {

}
