package br.com.barbearia.braddock.domain;

public enum TurnoEnum {
    PRIMEIRO, SEGUNDO
}
