const formulario = document.querySelector(".formContato");
const Inome = document.querySelector(".nomeContato");
const Iemail = document.querySelector(".emailContato");
const Inumero = document.querySelector(".numeroContato");
const Icontato = document.querySelector(".contatoContato");

function enviar() {
  fetch("http://localhost:8080/cliente/contato", {
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json"
    },
    method: "POST",
    body: JSON.stringify({
      nome: Inome.value,
      email: Iemail.value,
      numero: Inumero.value,
      mensagem: Icontato.value
    })
  })
    .then(function (res) {
      console.log(res);
    })
    .catch(function (res) {
      console.log(res);
    });
}

formulario.addEventListener("submit", function (event) {
  event.preventDefault();

  enviar();
});
