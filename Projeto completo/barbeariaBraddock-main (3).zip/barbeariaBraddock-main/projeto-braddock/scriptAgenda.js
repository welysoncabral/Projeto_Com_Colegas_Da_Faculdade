const formulario = document.querySelector(".formAgenda");
const Inome = document.querySelector(".nomeAgenda");
const Inumero = document.querySelector(".numeroAgenda");
const Idata = document.querySelector(".dataAgenda");
const Ihorario = document.querySelector(".horarioAgenda");
const Iservico = document.querySelector(".servicoAgenda");
const Ifuncionario = document.querySelector(".funcionarioAgenda");

function enviar() {
  const horarioInicio = Idata.value + "T" + Ihorario.value + ":00";
  console.log(horarioInicio);
  fetch("http://localhost:8080/agenda/agendar", {
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json"
    },
    method: "POST",
    body: JSON.stringify({
      nomeCliente: Inome.value,
      telefone: Inumero.value,
      nomeFuncionario: Ifuncionario.value,
      servico: Iservico.value,
      horarioInicio: horarioInicio
    })
  })
    .then(function (res) {
      console.log(res);
    })
    .catch(function (res) {
      console.log(res);
    });
}

formulario.addEventListener("submit", function (event) {
  event.preventDefault();

  enviar();
});
